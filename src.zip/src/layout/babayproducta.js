import '../App.css';
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';

function Babyproducts() {
  const responsive = {
    superLargeDesktop: {
      // the naming can be any, depends on you.
      breakpoint: { max: 4000, min: 3000 },
      items: 9
    },
    desktop: {
      breakpoint: { max: 3000, min: 1500 },
      items: 9
    },
    desktopp: {
      breakpoint: { max: 1500, min: 1150 },
      items: 7
    },
    tablet: {
      breakpoint: { max: 1150, min: 900 },
      items: 5
    },
    mobile: {
      breakpoint: { max: 900, min: 550 },
      items: 3
    },
    minimobile: {
      breakpoint: { max: 550, min: 424 },
      items: 2
    },
    minimobile: {
      breakpoint: { max: 424, min: 0 },
      items: 1
    }
  };
  return (
    <div className="p-3">
      <img className="mb-4 mt-3" src="https://k.nooncdn.com/cms/pages/20210614/fa074966c03379e28559de5944ea442f/en_mega-deal-title-01.png" />

      <div className="m-1">
        <Carousel responsive={responsive}>
          
          <div className="center">
            <img src="https://k.nooncdn.com/cms/pages/20210613/5bda691abbe18725a6d06c351638e448/en_mb-cat-module-02.png" />

          </div>
          <div className="center">
            <img src="https://k.nooncdn.com/cms/pages/20210613/5bda691abbe18725a6d06c351638e448/en_mb-cat-module-08.png" />

          </div>
          <div className="center">
            <img src="https://k.nooncdn.com/cms/pages/20210613/5bda691abbe18725a6d06c351638e448/en_mb-cat-module-07.png" />

          </div>
          <div className="center">
            <img src="https://k.nooncdn.com/cms/pages/20210613/5bda691abbe18725a6d06c351638e448/en_mb-cat-module-06.png" />

          </div>
          <div className="center">
            <img src="https://k.nooncdn.com/cms/pages/20210614/3b05771cb82674bb7ea38c4fa8968032/en_mb-cat-module-03.png" />

          </div>
          <div className="center">
            <img src="https://k.nooncdn.com/cms/pages/20210614/3b05771cb82674bb7ea38c4fa8968032/en_mb-cat-module-04.png" />

          </div>
          <div className="center">
            <img src="https://k.nooncdn.com/cms/pages/20210613/5bda691abbe18725a6d06c351638e448/en_mb-cat-module-09.png" />

          </div>
          <div className="center">
            <img src="https://k.nooncdn.com/cms/pages/20210613/5bda691abbe18725a6d06c351638e448/en_mb-cat-module-05.png" />

          </div>
          <div className="center">
            <img src="https://k.nooncdn.com/cms/pages/20210614/3b05771cb82674bb7ea38c4fa8968032/en_mb-cat-module-01.png"/>
          </div>

        </Carousel>
      </div>
    </div>
  );
}
export default Babyproducts