import Catagriescard from "../Components/catagriescard"
import React, { useState } from 'react';



function Catagriescardimage(){
    
const[imag,setimaage]=useState([
    {
        image:"https://k.nooncdn.com/cms/pages/20210609/ab5cd4c757d262915aae67797aa261f0/en_mb-category-01.png",
    },
    {
        image:"https://k.nooncdn.com/cms/pages/20210525/5e6536ce873b58ccd0cb4baf01ade972/en_mb-category-02.png",
    },
    {
        image:"https://k.nooncdn.com/cms/pages/20210525/5e6536ce873b58ccd0cb4baf01ade972/en_mb-category-03.png",
    },
    {
        image:"https://k.nooncdn.com/cms/pages/20210525/5e6536ce873b58ccd0cb4baf01ade972/en_mb-category-04.png",
    },
    {
        image:"https://k.nooncdn.com/cms/pages/20210525/5e6536ce873b58ccd0cb4baf01ade972/en_mb-category-06.png",
    },
    {
        image:"https://k.nooncdn.com/cms/pages/20210525/5e6536ce873b58ccd0cb4baf01ade972/en_mb-category-05.png",
    },
    {
        image:"https://k.nooncdn.com/cms/pages/20210525/5e6536ce873b58ccd0cb4baf01ade972/en_mb-category-01.png",
    },
    {
        image:"https://k.nooncdn.com/cms/pages/20210525/5e6536ce873b58ccd0cb4baf01ade972/en_mb-category-12.png",
    },
    {
        image:"https://k.nooncdn.com/cms/pages/20210525/5e6536ce873b58ccd0cb4baf01ade972/en_mb-category-14.png",
    },
    {
        image:"https://k.nooncdn.com/cms/pages/20210525/5e6536ce873b58ccd0cb4baf01ade972/en_mb-category-10.png",
    },
    {
        image:"https://k.nooncdn.com/cms/pages/20210525/5e6536ce873b58ccd0cb4baf01ade972/en_mb-category-15.png",
    },
    {
        image:"https://k.nooncdn.com/cms/pages/20210525/5e6536ce873b58ccd0cb4baf01ade972/en_mb-category-09.png",
    },
])
    return(
    <div className="row p-3">
   { imag.map((e,i)=>{
    return <Catagriescard images={e.image}/>
    }) }
    </div>
    );
}
export default Catagriescardimage
