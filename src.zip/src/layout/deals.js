import '../App.css';

function Deals(){
    return(
    <div className="">
        <img src="https://k.nooncdn.com/cms/pages/20210524/c9e52a0d65fcfed9cd59560d1f5e36a9/en_exclusive-deal-title-01.png"/>
     <div className="row pr-5 pb-5 pl-5">
     <img className="col-md-6 col-12 mt-4" src="https://k.nooncdn.com/cms/pages/20210612/f36b0afba39039cbe74f9e8007afd84b/en_cat-01.png" />
     <img className="col-md-6 col-12 mt-4" src="https://k.nooncdn.com/cms/pages/20210612/f36b0afba39039cbe74f9e8007afd84b/en_cat-02.png" />
     </div>
    
    </div>
    );
}

export default Deals