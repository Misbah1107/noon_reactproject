import '../App.css';

function Footer(){
    return(<div>
<div  className="footer">
        <div className="firstfooter">
           <div className="footer-links2">
           <h5>We're Always Here To Help</h5>
           <p className="footer-p">Reach out to us through any of these support channels</p>
           </div>
           <div className="footer-links">
           <div>
               <p className="footer-p hight"> Help CENTER </p>
               <h5> help.noon.com &nbsp; &nbsp; &nbsp; </h5>
           </div>
           <div >
               <p className="footer-p hight">Help SUPPORT</p>
               <h5> CARE@noon.com </h5>
           </div>
           </div>
        </div>
    </div>

<div className="respos">

    <div className="footer2">
    
    <div className="font">
        <p><b>ELECTRONICS</b></p>
        <p>Mobile</p>
        <p>Teblets</p>
        <p>Laptop</p>
        <p>Home Appliances</p>
        <p>Camera Photo & Video</p>
    </div>
    <div className="font">
        <p><b>FASHION</b></p>
        <p>Women Fashion</p>
        <p>Mens's Fashion</p>
        <p>Boys's Fashion</p>
        <p>Girl's Fashion</p>
        <p>Wathes</p>
    </div>
    <div className="font">
        <p><b>HOME AND KITCHEN</b></p>
        <p>Bath</p>
        <p>Home Decor</p>
        <p>Kitchen & Home Improvement</p>
        <p>Audio & Video</p>
        <p>Furniture</p>
    </div>
    <div className="font">
        <p><b>BEAUTY</b></p>
        <p>Fragrances</p>
        <p>Make-up</p>
        <p>Haircare</p>
        <p>Skincare</p>
        <p>Persnal Care</p>
    </div>
    <div className="font">
        <p><b>BABY</b></p>
        <p>Stroller & prams</p>
        <p>Car Seats</p>
        <p>Feeding</p>
        <p>Bathing & skin</p>
        <p>Daipering</p>
    </div>
    <div className="font">
        <p><b>TOP BRANDS</b></p>
        <p>Mothercare</p>
        <p>Apple</p>
        <p>Nike</p>
        <p>Sumsung</p>
        <p>Tefal</p>
    </div>
    <div className="font">
        <p><b>DAILY GROCERIES</b></p>
        <p>Fresh Product</p>
        <p>Dairy & Eggs</p>
        <p>Bread & Bakery</p>
        <p>Meat & seafood</p>
        <p>Panty Stapies</p>
    </div>     
    </div>
</div>


    </div>
    );
}
export default Footer