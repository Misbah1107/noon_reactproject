import '../App.css';
import Productcard from '../Components/productcard';
import { GiAlarmClock } from "react-icons/gi";

function Productadd(){
    return(
    <div className="Productadd p-3 mt-4">
        <img className="mb-3" width="100%" src="https://k.nooncdn.com/cms/pages/20210524/91e037edfb99fe52f09aa862da65bf7e/en_mega-deal-title-01.gif"/>
        <div>
            <img className="mb-4 col-md-3 col-sm-6" src="https://k.nooncdn.com/cms/pages/20210614/5f13d5612de4c10e48b33d1a276d5bc7/en_mb-01.png"/>
            <img className="mb-4 col-md-3 col-sm-6" src="https://k.nooncdn.com/cms/pages/20210614/5f13d5612de4c10e48b33d1a276d5bc7/en_mb-02.png"/>
            <img className="mb-4 col-md-3 col-sm-6" src="https://k.nooncdn.com/cms/pages/20210614/5f13d5612de4c10e48b33d1a276d5bc7/en_mb-03.png"/>
            <img className="mb-4 col-md-3 col-sm-6" src="https://k.nooncdn.com/cms/pages/20210614/5f13d5612de4c10e48b33d1a276d5bc7/en_mb-04.png"/>
        </div>
    </div>
    );
}
export default Productadd