import '../App.css';

function Electrinic(){

    return(
        <div className="p-5">
            <img src="https://k.nooncdn.com/cms/pages/20210604/6e860e51b19dea5b931c6b1f53f8d6d2/en_mobiles_elec-title.png"/>
            <div className="row">
                <img className="col-md-4 col-sm-6 col-12" src="https://k.nooncdn.com/cms/pages/20210120/800542152b0966457fa0968e13024ce3/en_cat-kitchen_dining.jpg"/>
                <img className="col-md-4 col-sm-6 col-12" src="https://k.nooncdn.com/cms/pages/20210120/800542152b0966457fa0968e13024ce3/en_cat-homeappliances.jpg"/>
                <img className="col-md-4 col-sm-6 col-12" src="https://k.nooncdn.com/cms/pages/20210120/800542152b0966457fa0968e13024ce3/en_cat-kitchenapp.jpg"/>
                <img className="col-md-4 col-sm-6 col-12" src="https://k.nooncdn.com/cms/pages/20210120/800542152b0966457fa0968e13024ce3/en_cat-homedecor.jpg"/>
                <img className="col-md-4 col-sm-6 col-12" src="https://k.nooncdn.com/cms/pages/20210120/800542152b0966457fa0968e13024ce3/en_cat-bedding.jpg"/>
                <img className="col-md-4 col-sm-6 col-12" src="https://k.nooncdn.com/cms/pages/20210120/800542152b0966457fa0968e13024ce3/en_cat-bath.jpg"/>
                <img className="col-md-4 col-sm-6 col-12" src="https://k.nooncdn.com/cms/pages/20210120/800542152b0966457fa0968e13024ce3/en_cat-tools_home.jpg"/>
                <img className="col-md-4 col-sm-6 col-12" src="https://k.nooncdn.com/cms/pages/20210120/800542152b0966457fa0968e13024ce3/en_cat-storage.jpg"/>
                <img className="col-md-4 col-sm-6 col-12" src="https://k.nooncdn.com/cms/pages/20210120/800542152b0966457fa0968e13024ce3/en_cat-furniture.jpg"/>

            </div>
        </div>
    );
}

export default Electrinic