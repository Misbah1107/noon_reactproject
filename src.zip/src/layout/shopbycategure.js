import '../App.css';
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';

function Shopcategory() {
  const responsive = {
    superLargeDesktop: {
      // the naming can be any, depends on you.
      breakpoint: { max: 4000, min: 3000 },
      items: 11
    },
    desktop: {
      breakpoint: { max: 3000, min: 1500 },
      items: 11
    },
    desktopp: {
      breakpoint: { max: 1500, min: 1150 },
      items: 9
    },
    tablet: {
      breakpoint: { max: 1150, min: 900 },
      items: 7
    },
    mobile: {
      breakpoint: { max: 900, min: 550 },
      items: 4
    },
    minimobile: {
      breakpoint: { max: 550, min: 400 },
      items: 3
    },
    minimobile: {
      breakpoint: { max: 400, min: 0 },
      items: 1
    }
  };
  return (
    <div className="p-3">
      <img className="mb-4 mt-3" width="100%" src="https://k.nooncdn.com/cms/pages/20210604/6e860e51b19dea5b931c6b1f53f8d6d2/en_shopbycat-title-01.png" />

      <div className="m-1">
        <Carousel responsive={responsive}>
          
          <div className="shopcategory">
            <img width="100%" src="https://k.nooncdn.com/cms/pages/20210525/5e6536ce873b58ccd0cb4baf01ade972/en_mb-category-11.png" />

          </div>
          <div className="shopcategory">
            <img width="100%" src="https://k.nooncdn.com/cms/pages/20210525/5e6536ce873b58ccd0cb4baf01ade972/en_mb-category-10.png" />

          </div>
          <div className="shopcategory">
            <img width="100%" src="https://k.nooncdn.com/cms/pages/20210525/5e6536ce873b58ccd0cb4baf01ade972/en_mb-category-13.png" />

          </div>
          <div className="shopcategory">
            <img width="100%" src="https://k.nooncdn.com/cms/pages/20210525/5e6536ce873b58ccd0cb4baf01ade972/en_mb-category-16.png" />

          </div>
          <div className="shopcategory">
            <img width="100%" src="https://k.nooncdn.com/cms/pages/20210525/5e6536ce873b58ccd0cb4baf01ade972/en_mb-category-17.png" />

          </div>
          <div className="shopcategory">
            <img width="100%" src="https://k.nooncdn.com/cms/pages/20210525/5e6536ce873b58ccd0cb4baf01ade972/en_mb-category-19.png" />

          </div>
          <div className="shopcategory">
            <img width="100%" src="https://k.nooncdn.com/cms/pages/20210525/5e6536ce873b58ccd0cb4baf01ade972/en_mb-category-07.png" />

          </div>
          <div className="shopcategory">
            <img width="100%" src="https://k.nooncdn.com/cms/pages/20210525/5e6536ce873b58ccd0cb4baf01ade972/en_mb-category-22.png" />

          </div>
          <div className="shopcategory">
            <img width="100%" src="https://k.nooncdn.com/cms/pages/20210525/5e6536ce873b58ccd0cb4baf01ade972/en_mb-category-21.png"/>
          </div>
          <div className="shopcategory">
            <img width="100%" src="https://k.nooncdn.com/cms/pages/20210525/5e6536ce873b58ccd0cb4baf01ade972/en_mb-category-18.png"/>
          </div>
          <div className="shopcategory">
            <img width="100%" src="https://k.nooncdn.com/cms/pages/20210525/5e6536ce873b58ccd0cb4baf01ade972/en_mb-category-23.png"/>
          </div>

        </Carousel>
      </div>
    </div>
  );
}
export default Shopcategory