import Categries from '../Components/Catagries'

function Searchcategries(){
    return(
<div>
    <Categries/>
</div>
    );
}
export default Searchcategries