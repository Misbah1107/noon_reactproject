import Header from '../Components/header'

function Navbar(){
    return(
     <Header/>
    );
}
export default Navbar