import react, { useState } from 'react'
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';
import Productcard from '../Components/productcard'

function Crousel() {
  const [items, setitems] = useState([
    {
      image: "https://z.nooncdn.com/products/tr:n-t_240/v1605989412/N12341446A_1.jpg",
      describe: "Apple MacBook Air 13.3-Inche Retina Display...",
      price: "2829.00",
      discountprice: "AED 3799",
      dicount: "25%",
      date: "tommorow jun 15",
    },
    {
      image: "https://z.nooncdn.com/products/tr:n-t_240/v1612944610/N44278658A_1.jpg",
      describe: "Apple MacBook Air 13.3-Inche Retina Display...",
      price: "2829.00",
      discountprice: "AED 3799",
      dicount: "25%",
      date: "tommorow jun 15",
    },
    {
      image: "https://z.nooncdn.com/products/tr:n-t_240/v1605900910/N36061300A_1.jpg",
      describe: "Apple MacBook Air 13.3-Inche Retina Display...",
      price: "2829.00",
      discountprice: "AED 3799",
      dicount: "25%",
      date: "tommorow jun 15",
    },
    {
      image: "https://z.nooncdn.com/products/tr:n-t_240/v1605813525/N11253377A_1.jpg",
      describe: "Apple MacBook Air 13.3-Inche Retina Display...",
      price: "2829.00",
      discountprice: "AED 3799",
      dicount: "25%",
      date: "tommorow jun 15",
    },
    {
      image: "https://z.nooncdn.com/products/tr:n-t_240/v1621419216/N47518953A_1.jpg",
      describe: "Apple MacBook Air 13.3-Inche Retina Display...",
      price: "2829.00",
      discountprice: "AED 3799",
      dicount: "25%",
      date: "tommorow jun 15",
    },
    {
      image: "https://z.nooncdn.com/products/tr:n-t_240/v1611138575/N41910684A_1.jpg",
      describe: "Apple MacBook Air 13.3-Inche Retina Display...",
      price: "2829.00",
      discountprice: "AED 3799",
      dicount: "25%",
      date: "tommorow jun 15",
    },
    {
      image: "https://z.nooncdn.com/products/tr:n-t_240/v1603701853/N41178624A_1.jpg",
      describe: "Apple MacBook Air 13.3-Inche Retina Display...",
      price: "2829.00",
      discountprice: "AED 3799",
      dicount: "25%",
      date: "tommorow jun 15",
    },
    {
      image: "https://z.nooncdn.com/products/tr:n-t_240/v1612159035/N44080243A_1.jpg",
      describe: "Apple MacBook Air 13.3-Inche Retina Display...",
      price: "2829.00",
      discountprice: "AED 3799",
      dicount: "25%",
      date: "tommorow jun 15",
    },
    {
      image: "https://z.nooncdn.com/products/tr:n-t_240/v1611138575/N42284105A_1.jpg",
      describe: "Apple MacBook Air 13.3-Inche Retina Display...",
      price: "2829.00",
      discountprice: "AED 3799",
      dicount: "25%",
      date: "tommorow jun 15",
    },
    {
      image: "https://z.nooncdn.com/products/tr:n-t_240/v1606564824/N42612126A_1.jpg",
      describe: "Apple MacBook Air 13.3-Inche Retina Display...",
      price: "2829.00",
      discountprice: "AED 3799",
      dicount: "25%",
      date: "tommorow jun 15",
    },
    
  ])

  const responsive = {
    superLargeDesktop: {
      // the naming can be any, depends on you.
      breakpoint: { max: 4000, min: 3000 },
      items: 7
    },
    desktop: {
      breakpoint: { max: 3000, min: 1500 },
      items: 7
    },
    tablet: {
      breakpoint: { max: 1500, min: 1024 },
      items: 6
    },
    tablet: {
      breakpoint: { max: 1024, min: 730 },
      items: 3
    },
    tablet: {
      breakpoint: { max: 730, min: 464 },
      items: 2
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 1
    }
  };

  return (

    <Carousel responsive={responsive}>
      {items.map((e, i) => {
        return <Productcard image={e.image} describe={e.describe} price={e.price} descounprice={e.discountprice} dicount={e.dicount} date={e.date} />
      })}
    </Carousel>
  );
}
export default Crousel