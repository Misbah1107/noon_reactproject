import react, { useState } from 'react'
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';
import Productcard from '../Components/productcard'

function Secondcrousel() {
  const [items, setitems] = useState([
    {
      image: "https://z.nooncdn.com/products/tr:n-t_240/v1615735526/N38728679A_1.jpg",
      describe: "Apple MacBook Air 13.3-Inche Retina Display...",
      price: "2829.00",
      discountprice: "AED 3799",
      dicount: "25%",
      date: "tommorow jun 15",
    },
    {
      image: "https://z.nooncdn.com/products/tr:n-t_240/v1600256244/N38844634A_1.jpg",
      describe: "Apple MacBook Air 13.3-Inche Retina Display...",
      price: "2829.00",
      discountprice: "AED 3799",
      dicount: "25%",
      date: "tommorow jun 15",
    },
    {
      image: "https://z.nooncdn.com/products/tr:n-t_240/v1615292698/N42664681A_1.jpg",
      describe: "Apple MacBook Air 13.3-Inche Retina Display...",
      price: "2829.00",
      discountprice: "AED 3799",
      dicount: "25%",
      date: "tommorow jun 15",
    },
    {
      image: "https://z.nooncdn.com/products/tr:n-t_240/v1615292705/N42664697A_4.jpg",
      describe: "Apple MacBook Air 13.3-Inche Retina Display...",
      price: "2829.00",
      discountprice: "AED 3799",
      dicount: "25%",
      date: "tommorow jun 15",
    },
    {
      image: "https://z.nooncdn.com/products/tr:n-t_240/v1600256256/N38844642A_1.jpg",
      describe: "Apple MacBook Air 13.3-Inche Retina Display...",
      price: "2829.00",
      discountprice: "AED 3799",
      dicount: "25%",
      date: "tommorow jun 15",
    },
    {
      image: "https://z.nooncdn.com/products/tr:n-t_240/v1612440228/N22547721A_5.jpg",
      describe: "Apple MacBook Air 13.3-Inche Retina Display...",
      price: "2829.00",
      discountprice: "AED 3799",
      dicount: "25%",
      date: "tommorow jun 15",
    },
    {
      image: "https://z.nooncdn.com/products/tr:n-t_240/v1606407153/N16173748A_1.jpg",
      describe: "Apple MacBook Air 13.3-Inche Retina Display...",
      price: "2829.00",
      discountprice: "AED 3799",
      dicount: "25%",
      date: "tommorow jun 15",
    },
    {
      image: "https://z.nooncdn.com/products/tr:n-t_240/v1518084727/N13262954A_1.jpg",
      describe: "Apple MacBook Air 13.3-Inche Retina Display...",
      price: "2829.00",
      discountprice: "AED 3799",
      dicount: "25%",
      date: "tommorow jun 15",
    },
    {
      image: "https://z.nooncdn.com/products/tr:n-t_240/v1553681418/N22828313A_1.jpg",
      describe: "Apple MacBook Air 13.3-Inche Retina Display...",
      price: "2829.00",
      discountprice: "AED 3799",
      dicount: "25%",
      date: "tommorow jun 15",
    },
    {
      image: "https://z.nooncdn.com/products/tr:n-t_240/v1587740816/N37396476A_1.jpg",
      describe: "Apple MacBook Air 13.3-Inche Retina Display...",
      price: "2829.00",
      discountprice: "AED 3799",
      dicount: "25%",
      date: "tommorow jun 15",
    },
    
  ])

  const responsive = {
    superLargeDesktop: {
      // the naming can be any, depends on you.
      breakpoint: { max: 4000, min: 3000 },
      items: 7
    },
    desktop: {
      breakpoint: { max: 3000, min: 1500 },
      items: 7
    },
    tablet: {
      breakpoint: { max: 1500, min: 1024 },
      items: 6
    },
    tablet: {
      breakpoint: { max: 1024, min: 730 },
      items: 3
    },
    tablet: {
      breakpoint: { max: 730, min: 464 },
      items: 2
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 1
    }
  };

  return (

    <Carousel responsive={responsive}>
      {items.map((e, i) => {
        return <Productcard image={e.image} describe={e.describe} price={e.price} descounprice={e.discountprice} dicount={e.dicount} date={e.date} />
      })}
    </Carousel>
  );
}
export default Secondcrousel