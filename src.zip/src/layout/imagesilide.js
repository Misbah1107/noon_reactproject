import Slideshow from '../Components/slider'

function Slider(){
    return(
   <Slideshow/>
    );
}
export default Slider