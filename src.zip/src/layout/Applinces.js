import '../App.css';

function Appliences(){
    return(
<div className="row pr-5 pl-5">


<div className="col-md-4">
    <img width="100%" src="https://k.nooncdn.com/cms/pages/20210213/3bc0a54552185869817ba573d97bba97/en_cat-module-appliances.jpg"/>
</div>
<div className="col-md-4">
    <img width="100%" src="https://k.nooncdn.com/cms/pages/20210213/3bc0a54552185869817ba573d97bba97/en_cat-module-home_kitchen.jpg"/>
</div>
<div className="col-md-4">
    <img width="100%" src="https://k.nooncdn.com/cms/pages/20210213/3bc0a54552185869817ba573d97bba97/en_cat-module-largeappliances.jpg"/>
</div>

</div>
    );
}
export default Appliences