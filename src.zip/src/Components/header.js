import '../App.css';
import React from 'react'
import { VscAccount} from "react-icons/vsc";
import { AiOutlineShoppingCart } from "react-icons/ai";

function Header() {
    return (
     
        <div className="main-eader-div">
           <img src="https://z.nooncdn.com/s/app/com/noon/images/logos/noon-black-en.svg"/>
           <div className="searc-div">
               <input className="search" placeholder="what are you looking for?"/>
           </div>
           <span className="arbi">العربية</span>
           <div className="select-country">
           <img src="https://z.nooncdn.com/s/app/com/common/images/flags/ae.svg"/>
           &nbsp;
           <sup> Ship to
               <p className="UAE">&nbsp; 	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;<b>UAE</b></p>
           </sup>
           </div>
           <div className="signin">
               Sign In
               <span className="login-icon">
               <VscAccount size="20"/>
               </span>
             
           </div>
           <div className="line"></div>
           <div className="cart">
               Cart
               <span className="login-icon">
               <AiOutlineShoppingCart size="20"/>
               </span>
             
           </div>
        </div>

    );
}

export default Header