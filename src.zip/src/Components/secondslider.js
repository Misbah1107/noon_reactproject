
import React from 'react';
import { Zoom } from 'react-slideshow-image';

const Slideshow = () => {
  const images = [
    'https://k.nooncdn.com/mon/1623527751145-ckpu6i67d0b9r2rrb9jip62z7.png',
    'https://k.nooncdn.com/cms/pages/20210613/de0879fab0d9084e52a066cbb96b1b1a/en_s-01.png',
    'https://k.nooncdn.com/cms/pages/20210613/4dbf23acb27455e01e73c514bed52aca/en_strip-01.gif',
  ];

  const zoomOutProperties = {
    indicators: true,
    scale: 0.4,
    // indicators: i => (<div className="indicator">{i + 1}</div>)
  }
  return (
    <div className="mt-4">
      <Zoom {...zoomOutProperties}>
        { images.map((each, index) => <img key={index} style={{width: "100%"}} src={each} />) }
      </Zoom>
    </div>
  )
}

export default Slideshow;
