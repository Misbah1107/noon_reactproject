
function Catagriescard(props){
 return(
  <div className="col-md-1 col-sm-2 col-3">
      <img width="100%" src={props.images}/>
  </div>

 );
}

export default Catagriescard