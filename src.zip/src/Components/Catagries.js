import '../App.css';


function Categries(){
    return(
   <div className="categrious">
       <p className="all-categories">ALL CATEGORIES</p><div className="line2"> </div>
       <div className="all-cetegrie">
           <p className="cetegrie-name">ELECTRONICS</p>
           <p className="cetegrie-name">MEN</p>
           <p className="cetegrie-name">WOMEN</p>
           <p className="cetegrie-name">HOME</p>
           <p className="cetegrie-name">BEAUTY & FRAGRANCE</p>
           <p className="cetegrie-name">BABY & TOYS</p>
           <p className="cetegrie-name">GROCERY</p>
           <p className="cetegrie-name">SPORTS</p>
           <p className="cetegrie-name">THE DUBAI MALL STORE</p>
       </div>
   </div>
    );
}
export default Categries