
import React from 'react';
import { Zoom } from 'react-slideshow-image';

const Slideshow = () => {
  const images = [
    'https://k.nooncdn.com/cms/pages/20210610/0c501871827d9abf1fb1d009529cf8aa/en_slider-01.gif',
    'https://k.nooncdn.com/cms/pages/20210609/acd337c70a9ef42fa7ba5ddc88a377c1/en_slider-01.gif',
    'https://k.nooncdn.com/cms/pages/20210610/d981949dcd2f5c054ddef85cffa4525b/en_slider-04.png',
    'https://k.nooncdn.com/cms/pages/20210311/ce770ca6b7b9e7a9a2332236eddc689e/en_slider-00.png',
    'https://k.nooncdn.com/cms/pages/20210609/1b8255c3046068d1a7877d3a900ae0cf/en_banner-01.jpg'
  ];

  const zoomOutProperties = {
    indicators: true,
    scale: 0.4,
    // indicators: i => (<div className="indicator">{i + 1}</div>)
  }
  return (
    <div>
      <Zoom {...zoomOutProperties}>
        { images.map((each, index) => <img key={index} style={{width: "100%"}} src={each} />) }
      </Zoom>
    </div>
  )
}

export default Slideshow;
