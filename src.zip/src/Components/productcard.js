import '../App.css';

function Productcard(props){

    return(
   <div className="product-div">
       <img width="100%" src={props.image}/>
       <div>
           <p className="card-desceription">{props.describe}</p>
           <p>AED <b>{props.price}</b><br/>
           <del className="card-desceription">{props.descounprice}</del><span className="discount card-desceription">{props.dicount}</span> </p>
           <p className="card-desceription">Arrives <b>{props.date}</b></p>
           <p className="card-desceription express">express</p>
       </div>
   </div>
    );
}
export default Productcard
