import Navbar from '../layout/navbar'
import Searchcategries from '../layout/categries'
import Slider from '../layout/imagesilide'
import Catagriescardimage from '../layout/categriescardimage'
import Crousel from '../layout/crousel'
import Productadd from '../layout/productadd'
import Babayproducts from '../layout/babayproducta'
import Secondslider from '../Components/secondslider'
import Deals from '../layout/deals'
import Shopcategory from '../layout/shopbycategure'
import Appliences from '../layout/Applinces'
import Secondcrousel from '../layout/secondcorusal'
import Electrinic from '../layout/mobileandelectronic'
import Footer from '../layout/footer'

import '../App.css';
import React from 'react';
// import { Carousel } from 'bootstrap'

function Home() {
    return (
        <div >

            <Navbar />
            <Searchcategries />
            <div className="bodydiv">
                <Slider />
                <Catagriescardimage />
                <img className="mt-3" width="100%" src="https://k.nooncdn.com/cms/pages/20210614/53b73d4b8b204c45c0e327248022a704/en_PLP-01.png" />
                <Productadd />
                <Babayproducts />
                <h5 className="laptops pr-2 pl-2 pt-2 ml-3">Top picks in laptop</h5>
                <Crousel />
                <Secondslider />
                <Deals />
                <h5 className="laptops pr-2 pl-2 pt-2 ml-3">Trending deals</h5>
                <Crousel />
                <img width="100%" src="https://k.nooncdn.com/cms/pages/20210429/a2a77ea3701f22c03f99d7d76cec59f8/en_nonvip-03.gif" />
                <Shopcategory />
                <div width="100vw">

                <img className="m-5" width="94%" src="https://k.nooncdn.com/cms/pages/20210610/b0010bfe830eae3f9a14c1955ece4378/en_mashreq-strip-02.gif" />
                </div>
                <Appliences />
                <h5 className="laptops pr-2 pl-2 pt-2 ml-3">Top picks in home & kitchen</h5>
                <Secondcrousel />
                <Electrinic />
            </div>
                <Footer/>

        </div>
    );
}
export default Home