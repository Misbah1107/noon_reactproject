import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'react-slideshow-image/dist/styles.css'
import Home from '../src/screens/home'

function App() {

  
  return (
    <div className="App">
      <Home/>
    </div>
  );
}

export default App;
